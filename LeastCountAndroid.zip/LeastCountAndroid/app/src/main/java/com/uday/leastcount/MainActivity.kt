package com.uday.leastcount

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val Forest = Color(0xFF14372D)
private val Mint = Color(0xFFB9F2D0)
private val Canvas = Color(0xFFF5F7F5)
private val Muted = Color(0xFF6B7771)
private val Danger = Color(0xFFB3261E)

data class Player(val id: Long, val name: String, val total: Int = 0, val out: Boolean = false)
data class Round(val number: Int, val scores: Map<Long, Int>, val names: Map<Long, String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LeastCountApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeastCountApp() {
    val players = remember {
        mutableStateListOf(
            Player(1, "Ashok"), Player(2, "Swapna"), Player(3, "Naveen"),
            Player(4, "Sushma"), Player(5, "Praveen"), Player(6, "Kittu")
        )
    }
    val rounds = remember { mutableStateListOf<Round>() }
    var targetText by remember { mutableStateOf("201") }
    var target by remember { mutableIntStateOf(201) }
    var targetDialog by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var editRound by remember { mutableStateOf<Round?>(null) }
    var editScores by remember { mutableStateOf(mutableStateMapOf<Long, String>()) }
    var roundScores by remember { mutableStateOf(mutableStateMapOf<Long, String>()) }
    var nextId by remember { mutableLongStateOf(7L) }
    var showReset by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    fun recompute() {
        val totals = players.associate { it.id to 0 }.toMutableMap()
        val eliminated = mutableSetOf<Long>()
        rounds.sortedBy { it.number }.forEach { r ->
            r.scores.forEach { (id, score) ->
                if (id in totals && id !in eliminated) {
                    val total = (totals[id] ?: 0) + score
                    totals[id] = total
                    if (total >= target) eliminated.add(id)
                }
            }
        }
        players.indices.forEach { i ->
            val p = players[i]
            players[i] = p.copy(total = totals[p.id] ?: 0, out = p.id in eliminated)
        }
    }

    fun saveRound() {
        val active = players.filter { !it.out }
        if (active.isEmpty()) return
        val parsed = active.associate { p -> p.id to ((roundScores[p.id] ?: "").toIntOrNull() ?: 0) }
        if (active.any { (roundScores[it.id] ?: "").isBlank() || (roundScores[it.id] ?: "").toIntOrNull() == null || (roundScores[it.id] ?: "").toInt() < 0 }) {
            statusMessage = "Enter a valid score (0 or more) for every active player."
            return
        }
        rounds.add(Round((rounds.maxOfOrNull { it.number } ?: 0) + 1, parsed, active.associate { it.id to it.name }))
        roundScores.clear()
        recompute()
        statusMessage = "Round saved."
    }

    val active = players.filter { !it.out }
    val winner = players.filter { !it.out }.singleOrNull()
    val roundNo = (rounds.maxOfOrNull { it.number } ?: 0) + 1

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Forest, onPrimary = Color.White, secondary = Color(0xFF2F8063), background = Canvas, surface = Color.White)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("LEAST COUNT", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("CARD GAME SCOREKEEPER", fontSize = 10.sp, color = Muted, letterSpacing = 1.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showReset = true }) {
                            Icon(Icons.Default.Refresh, contentDescription = "New game")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Canvas
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Column {
                                    Text("CURRENT TARGET", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("$target", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
                                        Text("points", color = Color.White.copy(alpha = .75f), modifier = Modifier.padding(bottom = 7.dp))
                                    }
                                }
                                OutlinedButton(onClick = { targetText = target.toString(); targetDialog = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("Edit target")
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                StatBox("ROUND", "$roundNo", Modifier.weight(1f))
                                StatBox("IN GAME", "${active.size}", Modifier.weight(1f))
                                StatBox("ELIMINATED", "${players.size - active.size}", Modifier.weight(1f))
                            }
                        }
                    }
                }
                if (winner != null && players.size > 1) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F4E8)), shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("🏆", fontSize = 28.sp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("WINNER", fontWeight = FontWeight.Bold, color = Forest, fontSize = 11.sp)
                                    Text(winner.name, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Forest)
                                    Text("Last player remaining", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
                item {
                    SectionTitle("PLAYER SCOREBOARD", "${players.size} players")
                }
                itemsIndexed(players, key = { _, p -> p.id }) { _, p ->
                    PlayerCard(
                        player = p,
                        target = target,
                        onRename = { newValue ->
                            val i = players.indexOfFirst { it.id == p.id }
                            if (i >= 0 && newValue.isNotBlank()) players[i] = players[i].copy(name = newValue.trim())
                        },
                        onRemove = {
                            players.removeAll { it.id == p.id }
                            rounds.indices.forEach { idx ->
                                val r = rounds[idx]
                                rounds[idx] = r.copy(scores = r.scores - p.id, names = r.names - p.id)
                            }
                            recompute()
                        }
                    )
                }
                item {
                    OutlinedButton(onClick = { newName = ""; addDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add player")
                    }
                }
                item {
                    SectionTitle("ROUND $roundNo", "Enter points")
                }
                item {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Add each active player's score for this round. Players reaching $target or more total points are eliminated.", color = Muted, fontSize = 13.sp)
                            if (active.isEmpty()) {
                                Text("No active players. Start a new game to play again.", color = Danger)
                            } else {
                                active.forEach { p ->
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text(p.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                        OutlinedTextField(
                                            value = roundScores[p.id] ?: "",
                                            onValueChange = { roundScores[p.id] = it.filter(Char::isDigit) },
                                            modifier = Modifier.width(112.dp),
                                            placeholder = { Text("0") },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                    }
                                }
                                Button(onClick = { saveRound() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                                    Text("Save round")
                                }
                            }
                            if (statusMessage.isNotBlank()) Text(statusMessage, color = if (statusMessage.startsWith("Enter")) Danger else Forest, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    SectionTitle("ROUND HISTORY", "${rounds.size} saved")
                }
                if (rounds.isEmpty()) {
                    item {
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Text("Your saved rounds will appear here. You can edit a round or delete it to correct a mistake.", modifier = Modifier.padding(18.dp), color = Muted, fontSize = 13.sp)
                        }
                    }
                } else {
                    itemsIndexed(rounds.sortedByDescending { it.number }, key = { _, r -> r.number }) { _, r ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Round ${r.number}", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        editRound = r
                                        editScores = mutableStateMapOf<Long, String>().apply {
                                            r.scores.forEach { (id, score) -> put(id, score.toString()) }
                                        }
                                    }) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Edit") }
                                    TextButton(onClick = {
                                        rounds.removeAll { it.number == r.number }
                                        recompute()
                                        statusMessage = "Round ${r.number} deleted."
                                    }) { Text("Delete", color = Danger) }
                                }
                                r.scores.forEach { (id, score) ->
                                    val name = players.find { it.id == id }?.name ?: r.names[id] ?: "Removed player"
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(name, color = Muted, fontSize = 13.sp)
                                        Text("+$score", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (targetDialog) {
            InputDialog(
                title = "Edit target score",
                label = "Target score",
                value = targetText,
                onValueChange = { targetText = it.filter(Char::isDigit) },
                onDismiss = { targetDialog = false },
                onConfirm = {
                    val v = targetText.toIntOrNull()
                    if (v != null && v > 0) {
                        target = v
                        recompute()
                        statusMessage = "Target updated to $target."
                        targetDialog = false
                    }
                },
                confirmText = "Save target"
            )
        }
        if (addDialog) {
            InputDialog(
                title = "Add player",
                label = "Player name",
                value = newName,
                onValueChange = { newName = it },
                onDismiss = { addDialog = false },
                onConfirm = {
                    if (newName.trim().isNotEmpty()) {
                        players.add(Player(nextId++, newName.trim()))
                        addDialog = false
                        statusMessage = "Player added."
                    }
                },
                confirmText = "Add"
            )
        }
        editRound?.let { round ->
            AlertDialog(
                onDismissRequest = { editRound = null },
                title = { Text("Edit round ${round.number}") },
                text = {
                    Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        round.scores.forEach { (id, oldScore) ->
                            val name = players.find { it.id == id }?.name ?: round.names[id] ?: "Removed player"
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(name, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                OutlinedTextField(
                                    value = editScores[id] ?: oldScore.toString(),
                                    onValueChange = { editScores[id] = it.filter(Char::isDigit) },
                                    modifier = Modifier.width(95.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val updated = round.scores.mapValues { (id, score) -> editScores[id]?.toIntOrNull() ?: score }
                        val idx = rounds.indexOfFirst { it.number == round.number }
                        if (idx >= 0) rounds[idx] = round.copy(scores = updated)
                        recompute()
                        editRound = null
                        statusMessage = "Round corrected and totals recalculated."
                    }) { Text("Save changes") }
                },
                dismissButton = { TextButton(onClick = { editRound = null }) { Text("Cancel") } }
            )
        }
        if (showReset) {
            AlertDialog(
                onDismissRequest = { showReset = false },
                title = { Text("Start a new game?") },
                text = { Text("This clears all saved rounds and scores. Your player names and target will stay.") },
                confirmButton = {
                    TextButton(onClick = {
                        rounds.clear()
                        players.indices.forEach { i -> players[i] = players[i].copy(total = 0, out = false) }
                        roundScores.clear()
                        statusMessage = "New game started."
                        showReset = false
                    }) { Text("New game", color = Danger) }
                },
                dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color.White.copy(alpha = .10f), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(label, color = Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionTitle(title: String, trailing: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Forest, letterSpacing = .6.sp)
        Text(trailing, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun PlayerCard(player: Player, target: Int, onRename: (String) -> Unit, onRemove: () -> Unit) {
    var renameDialog by remember { mutableStateOf(false) }
    var editedName by remember(player.name) { mutableStateOf(player.name) }
    val progress = (player.total.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f)
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(if (player.out) Color(0xFFFCE8E6) else Color(0xFFE0F4E8), CircleShape), contentAlignment = Alignment.Center) {
                    Text(player.name.take(1).uppercase(), color = if (player.out) Danger else Forest, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(player.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(if (player.out) "ELIMINATED" else "ACTIVE", color = if (player.out) Danger else Color(0xFF2F8063), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${player.total}", fontWeight = FontWeight.Black, fontSize = 23.sp, color = if (player.out) Danger else Forest)
                    Text("points", fontSize = 10.sp, color = Muted)
                }
                IconButton(onClick = { editedName = player.name; renameDialog = true }) {
                    Icon(Icons.Default.Edit, contentDescription = "Rename player", tint = Muted, modifier = Modifier.size(19.dp))
                }
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove player", tint = Muted, modifier = Modifier.size(19.dp))
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = if (player.out) Danger else Color(0xFF58A783),
                trackColor = Color(0xFFE8EDE9)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (player.out) "Target reached" else "${(target - player.total).coerceAtLeast(0)} points until target", color = Muted, fontSize = 11.sp)
                Text("$target target", color = Muted, fontSize = 11.sp)
            }
        }
    }
    if (renameDialog) {
        InputDialog(
            title = "Rename player",
            label = "Player name",
            value = editedName,
            onValueChange = { editedName = it },
            onDismiss = { renameDialog = false },
            onConfirm = {
                if (editedName.trim().isNotEmpty()) onRename(editedName.trim())
                renameDialog = false
            },
            confirmText = "Save"
        )
    }
}

@Composable
fun InputDialog(
    title: String,
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmText: String
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                label = { Text(label) },
                singleLine = true,
                keyboardOptions = if (label.contains("score", true)) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
