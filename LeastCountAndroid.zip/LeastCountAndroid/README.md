# Least Count — Android app source

A native Android app built with Kotlin and Jetpack Compose.

## Included features
- Default target score: 201, editable at any time
- Six starter players: Ashok, Swapna, Naveen, Sushma, Praveen, Kittu
- Add, rename, and remove players
- Enter scores for each active player each round
- Automatic cumulative totals and elimination at total >= target
- Last remaining active player is shown as winner
- Edit or delete saved rounds; totals/elimination are recalculated
- Start a new game without losing player names or target

## Build and run
1. Install Android Studio (current stable) and its Android SDK.
2. Open this `LeastCountAndroid` folder in Android Studio.
3. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35.
4. Select an emulator or connect an Android phone with USB debugging enabled.
5. Press **Run**.

To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Android Studio will show the APK location after the build completes.

## Important behavior
- The game starts with six players because six names were supplied.
- Enter a non-negative whole-number score for every active player in a round.
- A player is eliminated when their running total becomes equal to or greater than the target.
- Changing the target recalculates elimination from the saved round history.
- Scores and rounds currently live in app memory; closing the app fully will reset the match. Persistent local storage can be added next.
